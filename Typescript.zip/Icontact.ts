export interface IContact{
    mobile:number;
    email:string;
    getContactDetails();
}
