import {Manager} from './Manager';


/*var emp = new Employee("Prakash",45,false);
var emp1 = new Employee("Chetna",45,true);
emp.getEmployeeDetails();
emp1.getEmployeeDetails();*/
var mgr = new Manager("Pankaja",30,true,"Management",34905344,"p@gmail.com");
mgr.getEmployeeDetails();

